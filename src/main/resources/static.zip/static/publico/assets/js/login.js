document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('liberarLogin');

    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const userEmail = document.getElementById('email').value;
        const userSenha = document.getElementById('password').value;

        Swal.fire({
            title: 'Confirmação de Login',
            text: 'Você tem certeza de que deseja fazer login?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Sim, Fazer Login',
            cancelButtonText: 'Cancelar'
        }).then(async (result) => {
            if (result.isConfirmed) {
                try {
                    const response = await fetch('http://localhost:8080/login/usuario/client', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            email: userEmail,
                            senha: userSenha
                        }),
                    });

                    const data = await response.json();

                    if (response.ok) {
                        sessionStorage.setItem('JWT_TOKEN', data.token);
                        sessionStorage.setItem('usuario', JSON.stringify(data.user));

                        // Alerta de sucesso com SweetAlert2
                        Swal.fire({
                            title: 'Sucesso!',
                            text: data.message,
                            icon: 'success',
                            timer: 3000,
                            showConfirmButton: false
                        }).then(() => {
                            Swal.fire({
                                title: 'O que você gostaria de fazer agora?',
                                text: 'Escolha uma das opções abaixo:',
                                icon: 'question',
                                showCancelButton: true,
                                confirmButtonText: 'Ir para o Carrinho',
                                cancelButtonText: 'Ir para a Lista de Páginas'
                            }).then((result) => {
                                if (result.isConfirmed) {
                                    window.location.href = './carrinho.html';
                                } else if (result.dismiss === Swal.DismissReason.cancel) {
                                    Swal.fire({
                                        title: 'Escolha uma página:',
                                        icon: 'info',
                                        showCancelButton: true,
                                        confirmButtonText: 'Promoções',
                                        cancelButtonText: 'Masculina',
                                        footer: `
                                            <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='./femininas.html'">Feminina</button>
                                            <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='./acessorios.html'">Acessórios</button>
                                        `
                                    }).then((result) => {
                                        if (result.isConfirmed) {
                                            window.location.href = './index.html';
                                        } else if (result.dismiss === Swal.DismissReason.cancel) {
                                            window.location.href = './masculinas.html';
                                        }
                                    });
                                }
                            });
                        });
                    } else {

                        Swal.fire({
                            title: 'Erro!',
                            text: `Erro na requisição: ${data.error}`,
                            icon: 'error',
                            timer: 3000,
                            showConfirmButton: false
                        });
                    }
                } catch (error) {
                    Swal.fire({
                        title: 'Erro!',
                        text: `Erro na requisição: ${error.message}`,
                        icon: 'error',
                        timer: 3000,
                        showConfirmButton: false
                    });
                }
            }
        });
    });
});
