document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('liberarLogin');
    const errorMessageElement = document.getElementById('errorMessage');

    loginForm.addEventListener('submit', async (event) => {
        event.preventDefault();

        const userEmail = document.getElementById('email').value;
        const userSenha = document.getElementById('password').value;

        const confirmResult = await Swal.fire({
            title: 'Confirmação de Login',
            text: 'Você tem certeza de que deseja fazer login?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Sim, Fazer Login',
            cancelButtonText: 'Cancelar'
        });

        if (confirmResult.isConfirmed) {
            try {
             //   alert(`Enviando login com Email: ${userEmail} e Senha: ${userSenha}`);

                const response = await fetch('http://localhost:8080/login/admin/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: userEmail,
                        senha: userSenha
                    })
                });

                const data = await response.json();

             //   alert(`Status da resposta: ${response.status}`);
            //    alert(`Dados recebidos: ${JSON.stringify(data)}`);

                if (response.ok) {
                    sessionStorage.setItem('JWT_TOKEN', data.token);
                    sessionStorage.setItem('usuario', JSON.stringify(data.user));

                    await Swal.fire({
                        title: 'Sucesso!',
                        text: data.message,
                        icon: 'success',
                        timer: 3000,
                        showConfirmButton: false
                    });


                    const nextStep = await Swal.fire({
                        title: 'O que você gostaria de fazer agora?',
                        text: 'Escolha uma das opções abaixo:',
                        icon: 'question',
                        showCancelButton: true,
                        confirmButtonText: 'Ir para o ADMIN?',
                        cancelButtonText: 'Ir para a Lista de Páginas'
                    });

                    if (nextStep.isConfirmed) {
                        window.location.href = '../administrativo/adminIndex.html';
                    } else if (nextStep.dismiss === Swal.DismissReason.cancel) {
                        const pageChoice = await Swal.fire({
                            title: 'Escolha uma página:',
                            icon: 'info',
                            showCancelButton: true,
                            confirmButtonText: 'Voltar ao Inicio',
                            cancelButtonText: 'Editar Produtos',
                            footer: `
                                <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='../administrativo/listaProdutos.html'">listar Produtos</button>
                                <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='../administrativo/listaUsuarios.html'">listar Usuarios</button>
                            `
                        });

                        if (pageChoice.isConfirmed) {
                            window.location.href = './index.html';
                        } else if (pageChoice.dismiss === Swal.DismissReason.cancel) {
                            window.location.href = '../administrativo/adminEditarProduto.html';
                        }
                    }
                } else {
                    handleError(data.error || 'Desconhecido');
                }
            } catch (error) {
                handleError(error.message);
            }
        }
    });

    function handleError(message) {
        errorMessageElement.textContent = `Erro na requisição: ${message}`;
        errorMessageElement.classList.remove('hidden');
        Swal.fire({
            title: 'Erro!',
            text: `Erro na requisição: ${message}`,
            icon: 'error',
            timer: 3000,
            showConfirmButton: false
        });
    }

    async function acessarRecursoProtegido() {
        const token = sessionStorage.getItem('JWT_TOKEN');

        if (!token) {
            console.error('Token não encontrado');
            alert('Token não encontrado');
            return;
        }

        try {
            const response = await fetch('http://localhost:8080/administrativo', {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            const data = await response.json();
         //   alert(`Status da resposta de recurso protegido: ${response.status}`);
        //    alert(`Dados recebidos do recurso protegido: ${JSON.stringify(data)}`);

            if (response.ok) {
                console.log(data);
            } else {
             //   console.error('Erro:', data.error || 'Desconhecido');
              //  alert(`Erro: ${data.error || 'Desconhecido'}`);
            }
        } catch (error) {
          //  console.error('Erro:', error);
          //  alert(`Erro: ${error.message}`);
        }
    }
});















//document.addEventListener('DOMContentLoaded', () => {
//    const loginForm = document.getElementById('liberarLogin');
//    const errorMessageElement = document.getElementById('errorMessage');
//
//
//    loginForm.addEventListener('submit', async (event) => {
//        event.preventDefault();
//
//        const userEmail = document.getElementById('email').value;
//        const userSenha = document.getElementById('password').value;
//
//        const confirmResult = await Swal.fire({
//            title: 'Confirmação de Login',
//            text: 'Você tem certeza de que deseja fazer login?',
//            icon: 'question',
//            showCancelButton: true,
//            confirmButtonText: 'Sim, Fazer Login',
//            cancelButtonText: 'Cancelar'
//        });
//
//        if (confirmResult.isConfirmed) {
//            try {
//                const response = await fetch('http://localhost:8080/login', {
//                    method: 'POST',
//                    headers: {
//                        'Content-Type': 'application/json'
//                    },
//                    body: JSON.stringify({
//                        email: userEmail,
//                        senha: userSenha
//                    })
//                });
//
//                const data = await response.json();
//
//                if (response.ok) {
//                    // Armazenar o token e informações do usuário
//                    sessionStorage.setItem('JWT_TOKEN', data.token);
//                    sessionStorage.setItem('Perfil_Usuario', JSON.stringify(data.user));
//
//                    await Swal.fire({
//                        title: 'Sucesso!',
//                        text: data.message,
//                        icon: 'success',
//                        timer: 3000,
//                        showConfirmButton: false
//                    });
//
//                    // Redirecionar para a próxima etapa
//                    const nextStep = await Swal.fire({
//                        title: 'O que você gostaria de fazer agora?',
//                        text: 'Escolha uma das opções abaixo:',
//                        icon: 'question',
//                        showCancelButton: true,
//                        confirmButtonText: 'Ir para o ADMIN?',
//                        cancelButtonText: 'Ir para a Lista de Páginas'
//                    });
//
//                    if (nextStep.isConfirmed) {
//                        window.location.href = './administrativo/adminIndex.html';
//                    } else if (nextStep.dismiss === Swal.DismissReason.cancel) {
//                        const pageChoice = await Swal.fire({
//                            title: 'Escolha uma página:',
//                            icon: 'info',
//                            showCancelButton: true,
//                            confirmButtonText: 'Voltar ao Inicio',
//                            cancelButtonText: 'Editar Produtos',
//                            footer: `
//                                <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='./administrativo/listaProdutos.html'">listar Produtos</button>
//                                <button type="button" class="swal2-confirm swal2-styled" onclick="window.location.href='./administrativo/listaUsuarios.html'">listar Usuarios</button>
//                            `
//                        });
//
//                        if (pageChoice.isConfirmed) {
//                            window.location.href = './index.html';
//                        } else if (pageChoice.dismiss === Swal.DismissReason.cancel) {
//                            window.location.href = './administrativo/adminEditarProdutos.html';
//                        }
//                    }
//                } else {
//                    handleError(data.error || 'Desconhecido');
//                }
//            } catch (error) {
//                handleError(error.message);
//            }
//        }
//    });
//
//    function handleError(message) {
//        errorMessageElement.textContent = `Erro na requisição: ${message}`;
//        errorMessageElement.classList.remove('hidden');
//        Swal.fire({
//            title: 'Erro!',
//            text: `Erro na requisição: ${message}`,
//            icon: 'error',
//            timer: 3000,
//            showConfirmButton: false
//        });
//    }
//
//    async function acessarRecursoProtegido() {
//        const token = sessionStorage.getItem('JWT_TOKEN');
//
//        if (!token) {
//            console.error('Token não encontrado');
//            return;
//        }
//
//        try {
//            const response = await fetch('http://localhost:8080/administrativo', {
//                method: 'GET',
//                headers: {
//                    'Authorization': `Bearer ${token}`
//                }
//            });
//
//            const data = await response.json();
//            if (response.ok) {
//                console.log(data);
//            } else {
//                console.error('Erro:', data.error || 'Desconhecido');
//            }
//        } catch (error) {
//            console.error('Erro:', error);
//        }
//    }
//
//    // Chame a função para acessar um recurso protegido, se necessário
//    // acessarRecursoProtegido();
//});
