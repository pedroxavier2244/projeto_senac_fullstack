async function carregarDados() {
    const token = sessionStorage.getItem('JWT_TOKEN');
    if (!token) {
        console.error('Token não encontrado');
        Swal.fire({
            title: 'Erro!',
            text: 'Você precisa estar logado para acessar esta página.',
            icon: 'error',
            confirmButtonText: 'Ir para Login',
        }).then(() => {
            window.location.href = '../login.html';
        });
        return;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('change-password-form');
    const usuario = JSON.parse(sessionStorage.getItem('usuario')) || {};
    const token = sessionStorage.getItem('JWT_TOKEN');

    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const currentPassword = document.getElementById('current-password').value;
        const newPassword = document.getElementById('new-password').value;
        const confirmPassword = document.getElementById('confirm-password').value;

        if (newPassword !== confirmPassword) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'A nova senha e a confirmação não coincidem.'
            });
            return;
        }




        try {
            if (!usuario || !usuario.id) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: 'ID do usuário não encontrado.'
                });
                return;
            }

            const response = await fetch(`http://localhost:8080/usuarios/${usuario.id}/senha`, {
                    method: 'PATCH',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: `{"senhaAntiga": "${currentPassword}", "senhaNova": "${confirmPassword}"}`
                });

                if (response.ok) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso',
                        text: 'Senha alterada com sucesso!'
                    });
                    form.reset();
                } else {
                    const error = await response.json();
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: 'Erro ao alterar a senha: ' + (error.message || 'Erro desconhecido')
                    });
                }
            } catch (error) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: 'Erro na conexão com o servidor: ' + error.message
                });
            }
    });

    carregarDados();
});
